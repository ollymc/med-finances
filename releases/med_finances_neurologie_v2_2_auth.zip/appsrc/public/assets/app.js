document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-confirm]').forEach(btn => btn.addEventListener('click', e => {
    if (!confirm(btn.dataset.confirm)) e.preventDefault();
  }));
  const canvas = document.getElementById('wealthChart');
  if (canvas && window.Chart) {
    const data = JSON.parse(canvas.dataset.chart);
    new Chart(canvas, {
      type: 'line',
      data: { labels: data.labels, datasets: [
        { label: 'Secteur 1 immédiat', data: data.s1, borderWidth: 3, tension: .25 },
        { label: 'Secteur 2 après un an', data: data.s2, borderWidth: 3, tension: .25 }
      ]},
      options: { responsive:true, maintainAspectRatio:false, interaction:{mode:'index',intersect:false}, scales:{y:{ticks:{callback:v=>new Intl.NumberFormat('fr-FR',{style:'currency',currency:'EUR',maximumFractionDigits:0}).format(v)}}}}
    });
  }
});
