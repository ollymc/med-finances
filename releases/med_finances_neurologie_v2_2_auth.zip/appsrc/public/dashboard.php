<?php
declare(strict_types=1);

require_once __DIR__.'/../app/helpers.php';
require_once __DIR__.'/../app/Database.php';
require_once __DIR__.'/../app/TaxCalculator.php';
require_once __DIR__.'/../app/FinancialSimulator.php';

$defaults = require __DIR__.'/../config/defaults.php';
$message = $_SESSION['flash'] ?? '';
unset($_SESSION['flash']);
$userId = (int)$user['id'];
$currentId = isset($_GET['id']) ? (int)$_GET['id'] : null;
$params = $defaults;

if ($currentId) {
    $saved = $db->find($currentId, $userId);
    if ($saved) {
        $params = array_replace_recursive($defaults, $saved['payload']);
        // Migration transparente du nom de paramètre utilisé dans la v2.1.
        if (isset($saved['payload']['hospital_royalty_rate_s2']) && !isset($saved['payload']['hospital_royalty_rate'])) {
            $params['hospital_royalty_rate'] = (float)$saved['payload']['hospital_royalty_rate_s2'];
        }
        $params['name'] = $saved['name'];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? 'simulate';
    $currentId = !empty($_POST['simulation_id']) ? (int)$_POST['simulation_id'] : null;

    if ($action === 'delete' && $currentId) {
        $db->delete($currentId, $userId);
        $_SESSION['flash'] = 'Simulation supprimée.';
        header('Location: /?page=app'); exit;
    }
    if ($action === 'duplicate' && $currentId) {
        $newId = $db->duplicate($currentId, $userId);
        header('Location: /?page=app&id='.$newId); exit;
    }

    $params = $defaults;
    $params['name'] = trim((string)($_POST['name'] ?? $defaults['name']));
    foreach (['horizon_years','working_weeks','consultations_week','eeg_week','emg_standard_week','emg_complex_week','waiting_year_hospital_net','s1_hospital_net','s2_hospital_net','household_other_taxable_income','tax_parts','initial_assets','initial_debt','annual_real_estate_saving'] as $key) {
        $params[$key] = num($_POST, $key, (float)$defaults[$key]);
    }
    foreach (['professional_expense_rate','hospital_royalty_rate','social_rate_s1','social_rate_s2','annual_growth','activity_ramp_year1','activity_ramp_year2','savings_rate','investment_return','inflation'] as $key) {
        $params[$key] = num($_POST, $key, (float)$defaults[$key]*100)/100;
    }
    foreach ($defaults['tariffs'] as $key=>$value) {
        $params['tariffs'][$key] = num($_POST, 'tariff_'.$key, (float)$value);
    }

    if ($action === 'save') {
        $currentId = $db->save($currentId, $userId, $params['name'], $params);
        $message = 'Simulation enregistrée.';
    }
}

$result = (new FinancialSimulator(new TaxCalculator()))->simulate($params);
$savedList = $db->all($userId);
$last = end($result['rows']);
$chart = [
    'labels'=>array_column($result['rows'],'year'),
    's1'=>array_map(fn($r)=>round($r['wealth_s1']),$result['rows']),
    's2'=>array_map(fn($r)=>round($r['wealth_s2']),$result['rows']),
];
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Med Finances — Décision secteur 1 / secteur 2</title>
<link rel="stylesheet" href="/assets/app.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js" defer></script>
<script src="/assets/app.js" defer></script>
</head>
<body>
<header class="topbar">
  <div><strong>Med Finances</strong><span>Neurologie libérale — aide à la décision</span></div>
  <nav><a href="#decision">Décision</a><a href="#actes">Actes</a><a href="#fiscal">Fiscalité</a><a href="#patrimoine">Patrimoine</a><span class="user-chip"><?=e($user['full_name'])?></span><form method="post" action="/?page=logout" class="logout-form"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><button class="logout-button">Déconnexion</button></form></nav>
</header>
<main>
<?php if ($message): ?><div class="notice"><?=e($message)?></div><?php endif; ?>
<section class="hero" id="decision">
  <div>
    <p class="eyebrow">CHOIX RÉGLEMENTAIRE IRRÉVERSIBLE</p>
    <h1>Commencer en secteur 1 maintenant<br>ou attendre un an pour le secteur 2 hospitalier&nbsp;?</h1>
    <p>Le moteur compare le revenu disponible, le coût d’opportunité de l’année d’attente, le point de rattrapage et le patrimoine cumulé.</p>
  </div>
  <div class="decision-card <?= $result['final_wealth_difference'] >= 0 ? 'positive':'negative' ?>">
    <span>Valeur patrimoniale de l’attente à <?= (int)$params['horizon_years'] ?> ans</span>
    <strong><?=money($result['final_wealth_difference'])?></strong>
    <small><?= $result['crossing_year'] ? 'Rattrapage estimé en année '.$result['crossing_year'] : 'Pas de rattrapage sur l’horizon étudié' ?></small>
  </div>
</section>

<section class="kpis">
  <article><span>Coût net de l’attente — année 1</span><strong><?=money($result['waiting_cost_year1'])?></strong></article>
  <article><span>Patrimoine final secteur 1</span><strong><?=money($last['wealth_s1'])?></strong></article>
  <article><span>Patrimoine final secteur 2</span><strong><?=money($last['wealth_s2'])?></strong></article>
  <article><span>Écart de revenu cumulé</span><strong><?=money($result['final_income_difference'])?></strong></article>
</section>

<div class="layout">
<aside class="sidebar">
  <h2>Simulations enregistrées</h2>
  <?php if (!$savedList): ?><p class="muted">Aucune simulation sauvegardée.</p><?php endif; ?>
  <?php foreach($savedList as $s): ?>
    <a class="saved <?= $currentId===$s['id']?'active':'' ?>" href="/?page=app&id=<?=$s['id']?>"><strong><?=e($s['name'])?></strong><small><?=e(substr($s['updated_at'],0,10))?></small></a>
  <?php endforeach; ?>
  <div class="legal-note"><strong>Important</strong><p>Outil d’aide à la décision. Les cotisations, règles conventionnelles et impôts doivent être validés avec l’Urssaf, la CARMF, l’Assurance Maladie et un professionnel du droit ou du chiffre.</p></div>
</aside>

<div class="content">
<form method="post" class="panel form-panel" action="/?page=app<?= $currentId ? '&id='.$currentId : '' ?>">
<input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>">
<input type="hidden" name="simulation_id" value="<?= $currentId ?: '' ?>">
<div class="panel-head"><div><p class="eyebrow">PARAMÈTRES</p><h2>Hypothèses de simulation</h2></div><div class="actions"><button name="action" value="simulate" class="secondary">Recalculer</button><button name="action" value="save">Enregistrer</button><?php if($currentId): ?><button name="action" value="duplicate" class="secondary">Dupliquer</button><button name="action" value="delete" class="danger" data-confirm="Supprimer cette simulation ?">Supprimer</button><?php endif; ?></div></div>
<label class="full">Nom de la simulation<input name="name" value="<?=e((string)$params['name'])?>"></label>

<details open><summary>Activité neurologique</summary><div class="grid4">
<label>Semaines travaillées<input type="number" step="1" name="working_weeks" value="<?=$params['working_weeks']?>"></label>
<label>Consultations / semaine<input type="number" step="0.5" name="consultations_week" value="<?=$params['consultations_week']?>"></label>
<label>EEG / semaine<input type="number" step="0.5" name="eeg_week" value="<?=$params['eeg_week']?>"></label>
<label>EMG standard / semaine<input type="number" step="0.5" name="emg_standard_week" value="<?=$params['emg_standard_week']?>"></label>
<label>EMG complexe / semaine<input type="number" step="0.5" name="emg_complex_week" value="<?=$params['emg_complex_week']?>"></label>
<label>Montée en charge année 1 (%)<input type="number" step="1" name="activity_ramp_year1" value="<?=$params['activity_ramp_year1']*100?>"></label>
<label>Montée en charge année 2 (%)<input type="number" step="1" name="activity_ramp_year2" value="<?=$params['activity_ramp_year2']*100?>"></label>
<label>Croissance annuelle (%)<input type="number" step="0.1" name="annual_growth" value="<?=$params['annual_growth']*100?>"></label>
</div></details>

<details open id="actes"><summary>Tarifs secteur 1 / secteur 2</summary><div class="tariff-grid">
<div></div><strong>Secteur 1</strong><strong>Secteur 2</strong>
<?php foreach(['consultation'=>'Consultation neurologique','eeg'=>'EEG','emg_standard'=>'EMG standard','emg_complex'=>'EMG complexe'] as $k=>$label): ?>
<span><?=$label?></span><input type="number" step="0.01" name="tariff_s1_<?=$k?>" value="<?=$params['tariffs']['s1_'.$k]?>"><input type="number" step="0.01" name="tariff_s2_<?=$k?>" value="<?=$params['tariffs']['s2_'.$k]?>">
<?php endforeach; ?>
</div></details>

<details id="fiscal"><summary>Fiscalité et charges sociales</summary><div class="grid4">
<label>Charges professionnelles (%)<input type="number" step="0.1" name="professional_expense_rate" value="<?=$params['professional_expense_rate']*100?>"></label>
<label>Redevance hospitalière S1 et S2 (%)<input type="number" step="0.1" name="hospital_royalty_rate" value="<?=$params['hospital_royalty_rate']*100?>"></label>
<label>Cotisations sociales S1 (%)<input type="number" step="0.1" name="social_rate_s1" value="<?=$params['social_rate_s1']*100?>"></label>
<label>Cotisations sociales S2 (%)<input type="number" step="0.1" name="social_rate_s2" value="<?=$params['social_rate_s2']*100?>"></label>
<label>Nombre de parts fiscales<input type="number" step="0.5" min="1" name="tax_parts" value="<?=$params['tax_parts']?>"></label>
<label>Autres revenus imposables (€)<input type="number" step="100" name="household_other_taxable_income" value="<?=$params['household_other_taxable_income']?>"></label>
<label>Net hospitalier annuel S1 (€)<input type="number" step="100" name="s1_hospital_net" value="<?=$params['s1_hospital_net']?>"></label>
<label>Net hospitalier année d’attente (€)<input type="number" step="100" name="waiting_year_hospital_net" value="<?=$params['waiting_year_hospital_net']?>"></label>
<label>Net hospitalier annuel S2 (€)<input type="number" step="100" name="s2_hospital_net" value="<?=$params['s2_hospital_net']?>"></label>
</div></details>

<details id="patrimoine"><summary>Projection patrimoniale</summary><div class="grid4">
<label>Horizon (années)<input type="number" min="2" max="40" name="horizon_years" value="<?=$params['horizon_years']?>"></label>
<label>Patrimoine financier initial (€)<input type="number" step="1000" name="initial_assets" value="<?=$params['initial_assets']?>"></label>
<label>Dette initiale (€)<input type="number" step="1000" name="initial_debt" value="<?=$params['initial_debt']?>"></label>
<label>Taux d’épargne (%)<input type="number" step="1" name="savings_rate" value="<?=$params['savings_rate']*100?>"></label>
<label>Rendement annuel (%)<input type="number" step="0.1" name="investment_return" value="<?=$params['investment_return']*100?>"></label>
<label>Inflation annuelle (%)<input type="number" step="0.1" name="inflation" value="<?=$params['inflation']*100?>"></label>
<label>Épargne immobilière annuelle (€)<input type="number" step="500" name="annual_real_estate_saving" value="<?=$params['annual_real_estate_saving']?>"></label>
</div></details>
</form>

<section class="panel"><div class="panel-head"><div><p class="eyebrow">COMPARAISON DES ACTES</p><h2>Consultations, EEG et EMG</h2></div></div>
<div class="table-wrap"><table><thead><tr><th>Acte</th><th>Volume annuel</th><th>Tarif S1</th><th>Tarif S2</th><th>CA S1</th><th>CA S2</th><th>Écart annuel</th></tr></thead><tbody>
<?php foreach($result['acts'] as $a): ?><tr><td><strong><?=e($a['label'])?></strong></td><td><?=number_format($a['annual_volume'],0,',',' ')?></td><td><?=money($a['tariff_s1'])?></td><td><?=money($a['tariff_s2'])?></td><td><?=money($a['annual_s1'])?></td><td><?=money($a['annual_s2'])?></td><td class="<?= $a['difference']>=0?'good':'bad' ?>"><?=money($a['difference'])?></td></tr><?php endforeach; ?>
</tbody></table></div></section>

<section class="panel"><div class="panel-head"><div><p class="eyebrow">TRAJECTOIRE</p><h2>Patrimoine projeté</h2></div></div><canvas id="wealthChart" data-chart='<?=e(json_encode($chart, JSON_UNESCAPED_UNICODE))?>'></canvas></section>

<section class="panel"><div class="panel-head"><div><p class="eyebrow">DÉTAIL ANNUEL</p><h2>Comparaison fiscale et patrimoniale</h2></div></div>
<div class="table-wrap"><table><thead><tr><th>Année</th><th>CA S1</th><th>Disponible S1</th><th>Patrimoine S1</th><th>CA S2</th><th>Disponible S2</th><th>Patrimoine S2</th><th>Écart patrimoine</th></tr></thead><tbody>
<?php foreach($result['rows'] as $r): ?><tr><td><?=$r['year']?></td><td><?=money($r['s1']['gross_revenue'])?></td><td><?=money($r['s1']['available_income'])?></td><td><?=money($r['wealth_s1'])?></td><td><?=money($r['s2']['gross_revenue'])?></td><td><?=money($r['s2']['available_income'])?></td><td><?=money($r['wealth_s2'])?></td><td class="<?=($r['wealth_s2']-$r['wealth_s1'])>=0?'good':'bad'?>"><?=money($r['wealth_s2']-$r['wealth_s1'])?></td></tr><?php endforeach; ?>
</tbody></table></div></section>

<section class="panel roadmap"><h2>Modules maintenus dans l’architecture</h2><div class="module-grid"><article><strong>Fiscal et social</strong><p>BNC, SELARL, SELAS, URSSAF, CARMF, IR, IS, dividendes et versionnement des paramètres.</p></article><article><strong>Patrimoine</strong><p>PEA, CTO, assurance-vie, PER, immobilier, dette et projections en euros courants et constants.</p></article><article><strong>Décisions professionnelles</strong><p>Installation, cabinet, patientèle, secrétariat, assistant médical, arrêt d’activité et retraite.</p></article><article><strong>Exports et comparaison</strong><p>Simulations sauvegardées, duplication, comparaison multi-scénarios et futurs exports PDF/CSV.</p></article></div></section>
</div></div>
</main>
<footer>Med Finances — modèle paramétrable d’aide à la décision, sans valeur de conseil fiscal, juridique ou conventionnel.</footer>
</body></html>
