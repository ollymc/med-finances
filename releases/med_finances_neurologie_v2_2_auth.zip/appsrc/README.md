# Med Finances — secteur 1 maintenant ou secteur 2 dans un an

Application PHP 8.3 destinée à comparer deux choix irréversibles pour un neurologue hospitalier :

1. débuter immédiatement une activité libérale en secteur 1 ;
2. attendre une année puis débuter en secteur 2 hospitalier.

## Fonctions disponibles

- comparaison détaillée consultations de neurologie, EEG, EMG standard et EMG complexe ;
- année d’attente explicite pour le scénario secteur 2 ;
- coût d’opportunité, point de rattrapage et valeur patrimoniale de l’attente ;
- estimation des charges professionnelles, cotisations sociales et impôt sur le revenu ;
- projections patrimoniales jusqu’à 40 ans ;
- sauvegarde SQLite, chargement, duplication et suppression des simulations ;
- architecture prévue pour les modules BNC, SELARL, SELAS, URSSAF, CARMF, PER, PEA, CTO, assurance-vie et immobilier.

## Déploiement Dockge / TrueNAS SCALE

Le code PHP est copié dans l’image Docker. Seule la base SQLite est conservée dans un volume Docker nommé, ce qui évite les problèmes ACL du dataset TrueNAS.

```bash
docker compose down
docker compose up -d --build
```

Adresse par défaut : `http://IP_DU_NAS:8083`

Pour changer le port, modifier `8083:80` dans `compose.yaml`.

## Mise à jour

Après modification du code :

```bash
docker compose up -d --build --force-recreate
```

## Avertissement

Les tarifs, taux sociaux et hypothèses sont modifiables. L’outil fournit des estimations et ne remplace pas les calculs de l’Urssaf, de la CARMF, de l’Assurance Maladie, de la DGFiP ni le conseil d’un expert-comptable, avocat ou fiscaliste.

## Redevance hospitalière

Le scénario secteur 2 hospitalier applique une redevance distincte de 16 % par défaut sur le chiffre d’affaires libéral. Ce taux est modifiable dans l’interface et déduit avant le calcul des cotisations sociales et de l’impôt.


## Accès utilisateurs (v2.2)

L'adresse racine affiche désormais une page d'accueil publique. L'accès au simulateur nécessite un compte avec identité, login et mot de passe. Les mots de passe sont hachés avec `password_hash`, les formulaires disposent d'une protection CSRF et chaque simulation est rattachée à son propriétaire. Le premier compte créé récupère automatiquement les simulations existantes non rattachées.

La redevance hospitalière, réglée à 16 % par défaut, est appliquée aux activités libérales hospitalières des secteurs 1 et 2.
