<?php
declare(strict_types=1);

final class FinancialSimulator
{
    public function __construct(private TaxCalculator $tax) {}

    public function simulate(array $p): array
    {
        $years = max(2, min(40, (int)$p['horizon_years']));
        $rows = [];
        $wealth1 = (float)$p['initial_assets'] - (float)$p['initial_debt'];
        $wealth2 = $wealth1;
        $cumulative1 = 0.0;
        $cumulative2 = 0.0;
        $crossing = null;

        for ($year = 1; $year <= $years; $year++) {
            $growth = pow(1 + (float)$p['annual_growth'], $year - 1);
            $ramp = $year === 1 ? (float)$p['activity_ramp_year1'] : ($year === 2 ? (float)$p['activity_ramp_year2'] : 1.0);

            $s1 = $this->professionalYear($p, 's1', $growth, $ramp, (float)$p['hospital_royalty_rate']);
            $s1['hospital_net'] = $this->hospitalNet($p, $growth);
            $s1 = $this->finalize($s1, $p, (float)$p['social_rate_s1']);

            if ($year === 1) {
                $s2 = [
                    'gross_consultations'=>0,'gross_eeg'=>0,'gross_emg_standard'=>0,'gross_emg_complex'=>0,
                    'gross_revenue'=>0,'hospital_royalty'=>0,'professional_expenses'=>0,'social_contributions'=>0,
                    'professional_taxable'=>0,'income_tax'=>0,'available_income'=>$this->hospitalNet($p, $growth),
                    'hospital_net'=>$this->hospitalNet($p, $growth),
                ];
            } else {
                $s2Ramp = $year === 2 ? (float)$p['activity_ramp_year1'] : ($year === 3 ? (float)$p['activity_ramp_year2'] : 1.0);
                $s2 = $this->professionalYear($p, 's2', $growth, $s2Ramp, (float)$p['hospital_royalty_rate']);
                $s2['hospital_net'] = $this->hospitalNet($p, $growth);
                $s2 = $this->finalize($s2, $p, (float)$p['social_rate_s2']);
            }

            $save1 = max(0.0, $s1['available_income']) * (float)$p['savings_rate'] + (float)$p['annual_real_estate_saving'];
            $save2 = max(0.0, $s2['available_income']) * (float)$p['savings_rate'] + (float)$p['annual_real_estate_saving'];
            $wealth1 = $wealth1 * (1 + (float)$p['investment_return']) + $save1;
            $wealth2 = $wealth2 * (1 + (float)$p['investment_return']) + $save2;
            $cumulative1 += $s1['available_income'];
            $cumulative2 += $s2['available_income'];
            if ($crossing === null && $wealth2 >= $wealth1 && $year > 1) $crossing = $year;

            $rows[] = [
                'year'=>$year,'s1'=>$s1,'s2'=>$s2,
                'saving_s1'=>$save1,'saving_s2'=>$save2,
                'wealth_s1'=>$wealth1,'wealth_s2'=>$wealth2,
                'real_wealth_s1'=>$wealth1 / pow(1 + (float)$p['inflation'], $year),
                'real_wealth_s2'=>$wealth2 / pow(1 + (float)$p['inflation'], $year),
                'cumulative_available_s1'=>$cumulative1,'cumulative_available_s2'=>$cumulative2,
            ];
        }

        $first = $rows[0];
        $last = end($rows);
        return [
            'rows'=>$rows,
            'crossing_year'=>$crossing,
            'waiting_cost_year1'=>$first['s1']['available_income'] - $first['s2']['available_income'],
            'final_wealth_difference'=>$last['wealth_s2'] - $last['wealth_s1'],
            'final_income_difference'=>$last['cumulative_available_s2'] - $last['cumulative_available_s1'],
            'acts'=>$this->actComparison($p),
        ];
    }

    private function hospitalNet(array $p, float $growth): float
    {
        $gross = ((float)$p['hospital_gross_annual'] + (float)$p['hospital_annual_indemnities_gross']) * $growth;
        return max(0.0, $gross * (float)$p['hospital_net_rate']);
    }

    private function professionalYear(array $p, string $sector, float $growth, float $ramp, float $hospitalRoyaltyRate): array
    {
        $weeks = (float)$p['working_weeks'];
        $calc = fn(string $inputKey, string $tariffKey): float => (float)$p[$inputKey.'_week'] * $weeks * (float)$p['tariffs'][$sector.'_'.$tariffKey] * $growth * $ramp;
        $consult = $calc('consultations', 'consultation');
        $eeg = $calc('eeg', 'eeg');
        $emgS = $calc('emg_standard', 'emg_standard');
        $emgC = $calc('emg_complex', 'emg_complex');
        $gross = $consult + $eeg + $emgS + $emgC;
        return [
            'gross_consultations'=>$consult,'gross_eeg'=>$eeg,'gross_emg_standard'=>$emgS,'gross_emg_complex'=>$emgC,
            'gross_revenue'=>$gross,
            'hospital_royalty'=>$gross * $hospitalRoyaltyRate,
            'professional_expenses'=>$gross * (float)$p['professional_expense_rate'],
        ];
    }

    private function finalize(array $x, array $p, float $socialRate): array
    {
        $x['hospital_royalty'] = $x['hospital_royalty'] ?? 0.0;
        $base = max(0.0, $x['gross_revenue'] - $x['hospital_royalty'] - $x['professional_expenses']);
        $x['social_contributions'] = $base * $socialRate;
        $x['professional_taxable'] = max(0.0, $base - $x['social_contributions']);
        $taxable = $x['professional_taxable'] + (float)$p['household_other_taxable_income'];
        $x['income_tax'] = $this->tax->incomeTax($taxable, (float)$p['tax_parts']);
        $x['available_income'] = $x['professional_taxable'] - $x['income_tax'] + $x['hospital_net'];
        return $x;
    }

    private function actComparison(array $p): array
    {
        $labels = ['consultation'=>['Consultations de neurologie','consultations'],'eeg'=>['EEG','eeg'],'emg_standard'=>['EMG standard','emg_standard'],'emg_complex'=>['EMG complexe','emg_complex']];
        $out=[];
        foreach ($labels as $key=>$meta) {
            [$label,$inputKey] = $meta;
            $vol=(float)$p[$inputKey.'_week']*(float)$p['working_weeks'];
            $s1=(float)$p['tariffs']['s1_'.$key]; $s2=(float)$p['tariffs']['s2_'.$key];
            $out[]=['key'=>$key,'label'=>$label,'annual_volume'=>$vol,'tariff_s1'=>$s1,'tariff_s2'=>$s2,'annual_s1'=>$vol*$s1,'annual_s2'=>$vol*$s2,'difference'=>$vol*($s2-$s1)];
        }
        return $out;
    }
}
